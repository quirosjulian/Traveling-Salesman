# Traveling Salesman
# By Julian Quiros

import random


from earth_distance import *

def read_cities(file_name):
    """Reads in the Cities from the given file_name and return as a list of
    four tuples. Use as initial road_map."""

    stream = open(file_name, "r")
    road_map = []
    while True:
        str_line = stream.readline()
        if ("" == str_line):
            break
        (state, city, lat, long) = str_line.split("\t")
        l = len(long)
        long = long[:l-1]

        road_map.append((state, city, lat, long))
    return road_map

def print_cities(road_map):
    """Print a list of cities, along with their locations. Print only one or
    two digits after decimal point."""
    new_list=[]
    l = len(road_map)
    for i in range (0, l):
        new_list.append((road_map[i][1], "{:.2f}".format(float(road_map[i][2])), "{:.2f}".format(float(road_map[i][3]))))
    print(new_list)


def compute_total_distance(road_map):
    """Return, as a floater, sum of the distances of all the connections
    in the road_map. Remember it's a cycle, so for example Wyoming connects
    to Alabama."""
    dis = 0
    for i in range (0, len(road_map)):
        dis = dis + distance(float(road_map[i][2]), float(road_map[i][3]), float(road_map[(i + 1) % len(road_map)][2]), float(road_map[(i + 1) % len(road_map)][3]))
    return dis
            

def swap_adjacent_cities(road_map, index):
    """Take the city at location index in the road_map, and the city at location
    index+1(or at 0, if index refers to the last element in the list) swap
    their positions in the road_map, compute the new total distance, and return
    the tuple (new_road_map, new_total_distance)."""

    new_road_map = road_map[:]
    index = index % len(new_road_map)
    

    return swap_cities(road_map, index, (index + 1) % len(new_road_map))

    

def swap_cities(road_map, index1, index2):
    """Take the city at location index in the road_map, and the city at location
    index2, swap their positions in the road map and compute the new total
    distance, and return the tuple (new_road_map, new_total_distance). Allow
    the possibility that index1 = index2, and handle this case correctly."""

    new_road_map = road_map[:]
    a = new_road_map[index1]
    new_road_map[index1] = new_road_map[index2]
    new_road_map[index2] = a


    new_total_distance = compute_total_distance(new_road_map)
    return(new_road_map, new_total_distance)
    

def find_best_cycle(road_map):
    """Using a combination of swap_cities and swap_adjacent_cities, try 10000
    swaps, and each time keep the best cycle found so far. After 100000 swaps
    return the best cycle found so far."""
    new_road_map = road_map[:]
    best_distance = compute_total_distance(road_map)
    best_cycle = new_road_map
    for i in range (0, 10000):
        (adj_best_cycle, adj_best_distance) = swap_adjacent_cities(best_cycle, random.randint(0, len(new_road_map)))
        (swap_best_cycle,  swap_best_distance) = swap_cities(best_cycle, random.randint(0, len(new_road_map)-1), random.randint(0, len(new_road_map)-1))
        if (best_distance > adj_best_distance) or (best_distance > swap_best_distance):
            if adj_best_distance < swap_best_distance:
                best_distance = adj_best_distance
                best_cycle = adj_best_cycle
            else:
                best_distance = swap_best_distance
                best_cycle = swap_best_cycle
    return best_cycle



def print_map(road_map):
    """Prints, in an easily understandable format, the cities and their
    connections, along with the cost for each connection and the total cost."""
    j = len(road_map)
    difference = 0
    total_difference = 0
    for i in range(0, j):
        a = "{:.2f}".format(float(road_map[i][2]))
        b = "{:.2f}".format(float(road_map[i][3]))
        c = "{:.2f}".format(float(road_map[(i + 1) % len(road_map)][2]))
        d = "{:.2f}".format(float(road_map[(i + 1) % len(road_map)][3]))
        total_difference += distance(float(a), float(b), float(c), float(d))
        difference = "{:.2f}".format(float(distance(float(a), float(b), float(c), float(d))))
        
        print("From", road_map[i][1], "to", road_map[(i + 1) % len(road_map)][1], "is", difference, "miles.")
    print("Your total distance was", total_difference, "miles.")
        

def main():
    """Reads in and prints out the city data, then creates the "best" cycle and
    prints it out."""

    
    print_cities(read_cities("cities_data.txt"))
    find_best_cycle(read_cities("cities_data.txt"))
    print_map(find_best_cycle(read_cities("cities_data.txt")))

if __name__ == "__main__":
    main()
