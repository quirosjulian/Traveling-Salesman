import unittest
from cities import *

class TestCities(unittest.TestCase):

    def test_compute_total_distance(self):
        self.assertAlmostEqual(compute_total_distance(read_cities("cities_data.txt")), 58803.517540761306)
        
    def test_swap_adjacent_cities(self):
        road_map = [('Colorado', 'Denver', 39.74, -104.98),
                    ('Conneticut', 'Hartford', 41.77, -72.68),
                    ('Delaware', 'Dover', 39.16, -75.53),
                    ('Florida', 'Tallahassee', 30.45, -84.27)]
        self.assertEqual(swap_adjacent_cities(road_map, 2)[0][2],
                    ('Florida', 'Tallahassee', 30.45, -84.27))
        self.assertEqual(swap_adjacent_cities(road_map, 2) [0][3], ('Delaware', 'Dover', 39.16, -75.53))
        
    def test_swap_cities(self):
        road_map = [('Colorado', 'Denver', 39.74, -104.98),
                    ('Conneticut', 'Hartford', 41.77, -72.68),
                    ('Delaware', 'Dover', 39.16, -75.53),
                    ('Florida', 'Tallahassee', 30.45, -84.27)]
        self.assertEqual(swap_cities(road_map, 1, 2)[0][1], ('Delaware', 'Dover', 39.16, -75.53))
        self.assertEqual(swap_cities(road_map, 1, 2)[0][2], ('Conneticut', 'Hartford', 41.77, -72.68))
    def test_find_best_cycle(self):
        self.assertEqual(len(find_best_cycle(read_cities("cities_data.txt"))), len(read_cities("cities_data.txt")))
        self.assertFalse(find_best_cycle(read_cities("cities_data.txt")) == read_cities("cities_data.txt"))

unittest.main()
